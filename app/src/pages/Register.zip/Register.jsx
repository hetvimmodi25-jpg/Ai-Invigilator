import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth.js';

import { registerStudent } from "../services/authService";
const Register = () => {
  const navigate = useNavigate();

  const particleContainerRef = useRef(null);

 const [enrollmentNo, setEnrollmentNo] = useState('');
const [name, setName] = useState('');
const [email, setEmail] = useState('');
const [password, setPassword] = useState('');
const [confirmPassword, setConfirmPassword] = useState('');
const [phone, setPhone] = useState('');
const [course, setCourse] = useState('');
const [semester, setSemester] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Background particle animation effect - identical to Student Login
  useEffect(() => {
    const container = particleContainerRef.current;
    if (!container) return;

    const particleCount = 15;
    const intervals = [];
    const particles = [];

    for (let i = 0; i < particleCount; i++) {
      const dot = document.createElement('div');
      dot.className = 'absolute pointer-events-none bg-primary/10 rounded-full blur-sm transition-transform duration-[10000ms]';

      const size = Math.random() * 200 + 100;
      dot.style.width = `${size}px`;
      dot.style.height = `${size}px`;
      dot.style.left = `${Math.random() * 100}%`;
      dot.style.top = `${Math.random() * 100}%`;

      container.appendChild(dot);
      particles.push(dot);

      const interval = setInterval(() => {
        dot.style.transform = `translate(${Math.random() * 100 - 50}px, ${Math.random() * 100 - 50}px)`;
      }, 5000);

      intervals.push(interval);
    }

    return () => {
      intervals.forEach(clearInterval);
      particles.forEach((p) => p.remove());
    };
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!enrollmentNo ||
  !name ||
  !email ||
  !phone ||
  !course ||
  !semester ||
  !password ||
  !confirmPassword) {
      setError('Please fill in all fields.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    setIsSubmitting(true);
try {

  await studentRegister({
  enrollment_no: enrollmentNo,
  full_name: name,
  email,
  password,
  phone,
  course,
  semester,
});

alert("Registration Successful!");
navigate("/student-login");

} catch (err) {

  console.log(err);

  if (err.response) {
    console.log("Status:", err.response.status);
    console.log("Response Data:", err.response.data);
  }

  setError(err.response?.data?.message || err.message);
}};

  return (
    <div className="bg-background min-h-screen flex flex-col font-body-md text-on-background relative">
      {/* Embedded Custom CSS - shared with Student Login */}
      <style dangerouslySetInnerHTML={{
        __html: `
        .glass-card {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(226, 232, 240, 0.8);
        }
        .primary-gradient {
            background: linear-gradient(135deg, #004ac6 0%, #712ae2 100%);
        }
        .floating-label-input:focus-within label {
            transform: translateY(-20px) scale(0.85);
            color: #004ac6;
        }
        .input-glow:focus {
            box-shadow: 0 0 0 4px rgba(0, 74, 198, 0.1);
        }
        `
      }} />

      <div ref={particleContainerRef} className="fixed inset-0 pointer-events-none z-0 overflow-hidden"></div>

      {/* Top Navigation Anchor */}
      <header className="fixed top-0 w-full z-50 bg-surface/80 dark:bg-surface-dim/80 backdrop-blur-xl border-b border-outline-variant/30 shadow-sm">
        <div className="flex justify-between items-center h-16 px-gutter max-w-container-max mx-auto">
          <button type="button" onClick={() => navigate('/')} className="font-headline-md text-headline-md font-bold text-primary cursor-pointer hover:opacity-80 active:scale-95 transition-all">AI-Invigilator</button>
          <div className="flex gap-md">
            <button onClick={() => navigate('/admin-login')} className="text-on-surface-variant font-label-md text-label-md hover:bg-primary/5 px-md py-sm rounded-lg transition-colors cursor-pointer active:scale-95 transition-transform">
              Admin Login
            </button>
            <button onClick={() => navigate('/student-login')} className="bg-primary-container text-on-primary-container font-label-md text-label-md px-md py-sm rounded-lg shadow-sm cursor-pointer active:scale-95 transition-transform">
              Student Login
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Canvas */}
      <main className="flex-grow flex items-center justify-center pt-16 relative overflow-hidden z-10">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-primary/5 blur-[120px]"></div>
          <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-secondary/5 blur-[120px]"></div>
        </div>

        <div className="relative z-10 w-full max-w-[480px] p-md">
          <div className="glass-card rounded-[32px] p-xl shadow-sm border border-outline-variant/30">

            {/* Branding & Identity */}
            <div className="text-center mb-lg">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl primary-gradient text-white mb-md shadow-md">
                <span className="material-symbols-outlined !text-[32px]" style={{ fontVariationSettings: "'FILL' 1" }}>person_add</span>
              </div>
              <h1 className="font-headline-lg text-headline-lg text-on-surface mb-xs">Create Account</h1>
              <p className="font-body-md text-body-md text-on-surface-variant">Register for Secure Exam Access</p>
            </div>

            {/* Error Message */}
            {error && (
              <div className="mb-lg p-md bg-error-container/50 border border-error/20 rounded-xl flex gap-md items-start">
                <span className="material-symbols-outlined text-error !text-[20px]">error</span>
                <p className="font-body-md text-body-md text-on-error-container">{error}</p>
              </div>
            )}

            {/* Registration Form */}
            <form className="space-y-lg" onSubmit={handleSubmit}>

              <div className="relative">
  <label className="block font-label-md text-label-md text-on-surface-variant mb-xs ml-1">
    Enrollment Number
  </label>

  <input
    className="w-full h-12 px-4 bg-surface-container-low border border-outline-variant/50 rounded-xl"
    type="text"
    value={enrollmentNo}
    onChange={(e) => setEnrollmentNo(e.target.value)}
    placeholder="2026001"
  />
</div>

              {/* Name Field */}
              <div className="relative">
                <label className="block font-label-md text-label-md text-on-surface-variant mb-xs ml-1" htmlFor="name">Full Name</label>
                <div className="relative flex items-center">
                  <span className="material-symbols-outlined absolute left-4 text-outline !text-[20px]">person</span>
                  <input
                    className="w-full h-12 pl-12 pr-4 bg-surface-container-low border border-outline-variant/50 rounded-xl font-body-md text-body-md focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/5 transition-all outline-none"
                    id="name"
                    placeholder="Jane Doe"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
              </div>

              {/* Email Field */}
              <div className="relative">
                <label className="block font-label-md text-label-md text-on-surface-variant mb-xs ml-1" htmlFor="email">Email Address</label>
                <div className="relative flex items-center">
                  <span className="material-symbols-outlined absolute left-4 text-outline !text-[20px]">mail</span>
                  <input
                    className="w-full h-12 pl-12 pr-4 bg-surface-container-low border border-outline-variant/50 rounded-xl font-body-md text-body-md focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/5 transition-all outline-none"
                    id="email"
                    placeholder="student@university.edu"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="relative">
  <label className="block font-label-md text-label-md text-on-surface-variant mb-xs ml-1">
    Phone
  </label>

  <input
    className="w-full h-12 px-4 bg-surface-container-low border border-outline-variant/50 rounded-xl"
    type="text"
    value={phone}
    onChange={(e)=>setPhone(e.target.value)}
    placeholder="9876543210"
  />
</div>

<div className="relative">
<label className="block font-label-md text-label-md text-on-surface-variant mb-xs ml-1">
Course
</label>

<input
className="w-full h-12 px-4 bg-surface-container-low border border-outline-variant/50 rounded-xl"
type="text"
value={course}
onChange={(e)=>setCourse(e.target.value)}
placeholder="B.Tech"
/>

</div>

<div className="relative">
<label className="block font-label-md text-label-md text-on-surface-variant mb-xs ml-1">
Semester
</label>

<input
className="w-full h-12 px-4 bg-surface-container-low border border-outline-variant/50 rounded-xl"
type="text"
value={semester}
onChange={(e)=>setSemester(e.target.value)}
placeholder="8"
/>

</div>


              {/* Password Field */}
              <div className="relative">
                <label className="block font-label-md text-label-md text-on-surface-variant mb-xs ml-1" htmlFor="password">Password</label>
                <div className="relative flex items-center">
                  <span className="material-symbols-outlined absolute left-4 text-outline !text-[20px]">lock</span>
                  <input
                    className="w-full h-12 pl-12 pr-4 bg-surface-container-low border border-outline-variant/50 rounded-xl font-body-md text-body-md focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/5 transition-all outline-none"
                    id="password"
                    placeholder="••••••••"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>
              </div>

              {/* Confirm Password Field */}
              <div className="relative">
                <label className="block font-label-md text-label-md text-on-surface-variant mb-xs ml-1" htmlFor="confirm-password">Confirm Password</label>
                <div className="relative flex items-center">
                  <span className="material-symbols-outlined absolute left-4 text-outline !text-[20px]">lock_reset</span>
                  <input
                    className="w-full h-12 pl-12 pr-4 bg-surface-container-low border border-outline-variant/50 rounded-xl font-body-md text-body-md focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/5 transition-all outline-none"
                    id="confirm-password"
                    placeholder="••••••••"
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                  />
                </div>
              </div>

              {/* Primary Register Button */}
              <button
                className="w-full h-14 primary-gradient text-on-primary font-title-lg text-title-lg rounded-xl shadow-md hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-sm disabled:opacity-60"
                type="submit"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Creating Account…' : 'Create Account'}
                <span className="material-symbols-outlined">arrow_forward</span>
              </button>
            </form>

            {/* Login Anchor */}
            <div className="mt-xl text-center">
              <p className="font-body-md text-body-md text-on-surface-variant">
                Already have an account?{' '}
                <Link className="text-primary font-semibold hover:underline" to="/student-login">Sign In</Link>
              </p>
            </div>
          </div>

          {/* Integrity Badges */}
          <div className="mt-lg flex justify-center gap-lg opacity-40 grayscale">
            <div className="flex items-center gap-xs font-label-md text-[10px] tracking-widest uppercase">
              <span className="material-symbols-outlined !text-[14px]">shield</span>
              AES-256 SECURED
            </div>
            <div className="flex items-center gap-xs font-label-md text-[10px] tracking-widest uppercase">
              <span className="material-symbols-outlined !text-[14px]">auto_awesome</span>
              AI-POWERED
            </div>
          </div>
        </div>
      </main>

      {/* Footer Identity */}
      <footer className="relative w-full py-xl mt-auto border-t border-outline-variant/30 bg-surface-container-lowest dark:bg-surface-dim z-10">
        <div className="flex flex-col md:flex-row justify-between items-center px-gutter gap-lg max-w-container-max mx-auto">
          <button type="button" onClick={() => navigate('/')} className="font-title-lg text-title-lg font-bold text-primary cursor-pointer hover:opacity-80 transition-opacity">AI-Invigilator</button>
          <div className="flex flex-wrap justify-center gap-lg">
            <a className="font-body-md text-body-md text-on-surface-variant hover:text-secondary transition-colors" href="#privacy">Privacy Policy</a>
            <a className="font-body-md text-body-md text-on-surface-variant hover:text-secondary transition-colors" href="#terms">Terms of Service</a>
            <a className="font-body-md text-body-md text-on-surface-variant hover:text-secondary transition-colors" href="#security">Security Whitepaper</a>
            <a className="font-body-md text-body-md text-on-surface-variant hover:text-secondary transition-colors" href="#support">Support</a>
          </div>
          <p className="font-body-md text-body-md text-on-surface-variant">© 2024 AI-Invigilator. Secure. Objective. Sophisticated.</p>
        </div>
      </footer>
    </div>
  );
};

export default Register;
