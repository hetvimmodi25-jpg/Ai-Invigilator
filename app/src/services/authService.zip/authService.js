import API from "./api";

// Student Registration
export async function registerStudent(data) {
  const response = await API.post("/auth/register", data);
  return response.data;
}

// Student Login

export async function loginStudent(credentials) {
  const response = await API.post("/auth/login", credentials);
    localStorage.setItem("token", response.data.token);
    localStorage.setItem("student", JSON.stringify(response.data.student));

    return response.data.student;
}
// Student Logout
export function logoutStudent() {
  localStorage.removeItem("token");
  localStorage.removeItem("student");
}

// Student Session
export function getStudentSession() {
  const student = localStorage.getItem("student");
  return student ? JSON.parse(student) : null;
}

// Admin
export {
  loginAdmin,
  logoutAdmin,
  getAdminSession,
} from "./adminService";

// Exam
export async function startExam(data) {
  const response = await API.post("/exam/start", data);
  return response.data;
}

export async function getQuestions(examId) {
    const response = await API.get(`/exam/questions/${examId}`);
    return response.data.questions;
}